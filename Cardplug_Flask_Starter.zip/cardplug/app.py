import os
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from urllib.parse import urlparse

from flask import Flask, render_template, redirect, url_for, flash, request, abort
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required, current_user
from flask_wtf import FlaskForm, CSRFProtect
from wtforms import StringField, PasswordField, SubmitField, SelectField, DecimalField, TextAreaField
from wtforms.validators import DataRequired, Email, Length, EqualTo, NumberRange, Optional
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy import select

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-only-change-this-before-deploying')
database_url = os.environ.get('DATABASE_URL', 'sqlite:///cardplug.db')
if database_url.startswith('postgres://'):
    database_url = database_url.replace('postgres://', 'postgresql://', 1)
app.config['SQLALCHEMY_DATABASE_URI'] = database_url
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['SESSION_COOKIE_SECURE'] = os.environ.get('COOKIE_SECURE', 'false').lower() == 'true'
app.config['WTF_CSRF_TIME_LIMIT'] = 3600

db = SQLAlchemy(app)
csrf = CSRFProtect(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
login_manager.login_message_category = 'info'

STATUSES = ['Pending review', 'Under review', 'Approved', 'Paid', 'Rejected']
CARD_TYPES = [('Amazon', 'Amazon'), ('Apple', 'Apple'), ('Google Play', 'Google Play'), ('Steam', 'Steam'), ('iTunes', 'iTunes'), ('Other', 'Other')]

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(254), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    is_admin = db.Column(db.Boolean, default=False, nullable=False)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    trades = db.relationship('Trade', backref='customer', lazy=True)
    def set_password(self, password): self.password_hash = generate_password_hash(password)
    def check_password(self, password): return check_password_hash(self.password_hash, password)

class Rate(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    card_type = db.Column(db.String(40), unique=True, nullable=False)
    ngn_per_usd = db.Column(db.Numeric(12, 2), nullable=False, default=Decimal('1000.00'))
    updated_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc), nullable=False)

class Trade(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False, index=True)
    card_type = db.Column(db.String(40), nullable=False)
    card_currency = db.Column(db.String(3), nullable=False, default='USD')
    face_value = db.Column(db.Numeric(12, 2), nullable=False)
    quoted_rate = db.Column(db.Numeric(12, 2), nullable=False)
    estimated_payout = db.Column(db.Numeric(14, 2), nullable=False)
    status = db.Column(db.String(30), nullable=False, default='Pending review')
    customer_note = db.Column(db.String(500), nullable=True)
    admin_note = db.Column(db.String(500), nullable=True)
    payout_reference = db.Column(db.String(100), nullable=True)
    created_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    updated_at = db.Column(db.DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc), nullable=False)

class RegisterForm(FlaskForm):
    name = StringField('Full name', validators=[DataRequired(), Length(min=2, max=100)])
    email = StringField('Email', validators=[DataRequired(), Email(), Length(max=254)])
    password = PasswordField('Password (minimum 10 characters)', validators=[DataRequired(), Length(min=10, max=128)])
    confirm = PasswordField('Confirm password', validators=[DataRequired(), EqualTo('password', message='Passwords must match.')])
    submit = SubmitField('Create account')

class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Sign in')

class TradeForm(FlaskForm):
    card_type = SelectField('Gift card brand', choices=CARD_TYPES, validators=[DataRequired()])
    face_value = DecimalField('Card face value (USD)', places=2, validators=[DataRequired(), NumberRange(min=1, max=100000)])
    customer_note = TextAreaField('Additional note (optional)', validators=[Optional(), Length(max=500)])
    submit = SubmitField('Request a quote')

class RateForm(FlaskForm):
    ngn_per_usd = DecimalField('NGN per USD', places=2, validators=[DataRequired(), NumberRange(min=1, max=10000000)])
    submit = SubmitField('Save rate')

class TradeUpdateForm(FlaskForm):
    status = SelectField('Status', choices=[(s, s) for s in STATUSES], validators=[DataRequired()])
    admin_note = TextAreaField('Admin note', validators=[Optional(), Length(max=500)])
    payout_reference = StringField('Payout reference (optional)', validators=[Optional(), Length(max=100)])
    submit = SubmitField('Update trade')

@login_manager.user_loader
def load_user(user_id):
    return db.session.get(User, int(user_id))

@app.template_filter('ngn')
def ngn(value):
    try: return '₦' + format(Decimal(value), ',.2f')
    except Exception: return '₦0.00'

@app.context_processor
def inject_globals():
    return {'now_year': datetime.now().year, 'trade_statuses': STATUSES}

@app.after_request
def security_headers(response):
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    response.headers['Permissions-Policy'] = 'camera=(), microphone=(), geolocation=()'
    response.headers['Content-Security-Policy'] = "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'; img-src 'self' data:; form-action 'self'; frame-ancestors 'none'; base-uri 'self'"
    if request.is_secure or app.config['SESSION_COOKIE_SECURE']:
        response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
    return response

@app.route('/')
def index():
    rates = db.session.scalars(select(Rate).order_by(Rate.card_type)).all()
    return render_template('index.html', rates=rates)

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated: return redirect(url_for('dashboard'))
    form = RegisterForm()
    if form.validate_on_submit():
        email = form.email.data.strip().lower()
        if db.session.scalar(select(User).where(User.email == email)):
            flash('An account with that email already exists.', 'error')
        else:
            user = User(name=form.name.data.strip(), email=email)
            user.set_password(form.password.data)
            db.session.add(user); db.session.commit()
            login_user(user)
            flash('Account created successfully.', 'success')
            return redirect(url_for('dashboard'))
    return render_template('auth.html', form=form, mode='register')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated: return redirect(url_for('dashboard'))
    form = LoginForm()
    if form.validate_on_submit():
        email = form.email.data.strip().lower()
        user = db.session.scalar(select(User).where(User.email == email))
        if user and user.check_password(form.password.data):
            login_user(user, remember=False)
            return redirect(url_for('admin_dashboard' if user.is_admin else 'dashboard'))
        flash('Email or password is incorrect.', 'error')
    return render_template('auth.html', form=form, mode='login')

@app.post('/logout')
@login_required
def logout():
    logout_user(); flash('You have signed out.', 'info'); return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    trades = db.session.scalars(select(Trade).where(Trade.user_id == current_user.id).order_by(Trade.created_at.desc())).all()
    return render_template('dashboard.html', trades=trades)

@app.route('/trade/new', methods=['GET', 'POST'])
@login_required
def new_trade():
    form = TradeForm()
    rates = {r.card_type: r for r in db.session.scalars(select(Rate)).all()}
    if form.validate_on_submit():
        brand = form.card_type.data
        rate = rates.get(brand)
        if not rate:
            flash('A rate is not available for that card brand yet. Please contact support.', 'error')
        else:
            amount = Decimal(form.face_value.data)
            estimate = (amount * Decimal(rate.ngn_per_usd)).quantize(Decimal('0.01'))
            trade = Trade(user_id=current_user.id, card_type=brand, face_value=amount,
                          quoted_rate=rate.ngn_per_usd, estimated_payout=estimate,
                          customer_note=(form.customer_note.data or '').strip() or None)
            db.session.add(trade); db.session.commit()
            flash(f'Trade request #{trade.id} submitted. The estimate is not a guaranteed payout.', 'success')
            return redirect(url_for('dashboard'))
    return render_template('trade_new.html', form=form, rates=rates)

@app.route('/admin')
@login_required
def admin_dashboard():
    if not current_user.is_admin: abort(403)
    trades = db.session.scalars(select(Trade).order_by(Trade.created_at.desc()).limit(200)).all()
    rates = db.session.scalars(select(Rate).order_by(Rate.card_type)).all()
    return render_template('admin.html', trades=trades, rates=rates)

@app.route('/admin/rates/<int:rate_id>', methods=['GET', 'POST'])
@login_required
def update_rate(rate_id):
    if not current_user.is_admin: abort(403)
    rate = db.get_or_404(Rate, rate_id); form = RateForm(obj=rate)
    if form.validate_on_submit():
        rate.ngn_per_usd = form.ngn_per_usd.data
        db.session.commit(); flash(f'{rate.card_type} rate updated.', 'success')
        return redirect(url_for('admin_dashboard'))
    return render_template('rate_edit.html', form=form, rate=rate)

@app.route('/admin/trades/<int:trade_id>', methods=['GET', 'POST'])
@login_required
def update_trade(trade_id):
    if not current_user.is_admin: abort(403)
    trade = db.get_or_404(Trade, trade_id); form = TradeUpdateForm(obj=trade)
    if form.validate_on_submit():
        trade.status = form.status.data
        trade.admin_note = (form.admin_note.data or '').strip() or None
        trade.payout_reference = (form.payout_reference.data or '').strip() or None
        db.session.commit(); flash(f'Trade #{trade.id} updated.', 'success')
        return redirect(url_for('admin_dashboard'))
    return render_template('trade_edit.html', form=form, trade=trade)

@app.route('/health')
def health():
    return {'status': 'ok'}, 200

@app.errorhandler(403)
def forbidden(_): return render_template('error.html', code=403, message='You do not have permission to view this page.'), 403
@app.errorhandler(404)
def not_found(_): return render_template('error.html', code=404, message='The page you requested could not be found.'), 404

with app.app_context():
    db.create_all()
    for brand, _label in CARD_TYPES:
        if not db.session.scalar(select(Rate).where(Rate.card_type == brand)):
            db.session.add(Rate(card_type=brand, ngn_per_usd=Decimal('1000.00')))
    admin_email = os.environ.get('ADMIN_EMAIL', '').strip().lower()
    admin_password = os.environ.get('ADMIN_PASSWORD', '')
    if admin_email and admin_password and not db.session.scalar(select(User).where(User.email == admin_email)):
        admin = User(name='Cardplug Admin', email=admin_email, is_admin=True)
        admin.set_password(admin_password); db.session.add(admin)
    db.session.commit()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=int(os.environ.get('PORT', 5000)), debug=False)
