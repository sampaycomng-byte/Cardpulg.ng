# Cardplug — Flask gift-card trade-request starter

A responsive Flask website starter for Cardplug with customer registration/login, an indicative NGN rate board, customer trade-request history, and an admin area to edit rates and update request statuses.

## Important scope and limitations

This is a **trade-request and admin workflow starter**, not a production-ready automated gift-card exchange. It does not verify card balances, accept uploads, redeem gift cards, or transfer funds. The “Paid” status is only a record entered by an administrator. Do not claim or imply that a payout happened unless a real payment provider confirms it.

Before handling real money, obtain appropriate legal/compliance advice for your operating location, implement fraud and identity checks, connect a reputable card-verification workflow and payout provider, add monitoring/backups/rate limiting, and perform security testing. Never collect gift-card PINs in notes or plain text.

## Run locally on Windows

1. Install Python 3.11+ from https://www.python.org/downloads/ (enable **Add Python to PATH**).
2. Extract this ZIP into a folder such as `C:\\Cardplug`.
3. Open Command Prompt in that folder.
4. Create and activate a virtual environment:

   ```bat
   py -m venv .venv
   .venv\\Scripts\\activate
   ```

5. Install dependencies:

   ```bat
   pip install -r requirements.txt
   ```

6. Set a development secret and run the app:

   ```bat
   set SECRET_KEY=replace-this-with-a-long-random-secret
   py app.py
   ```

7. Visit http://127.0.0.1:5000

The local development database is SQLite (`cardplug.db`) and is created automatically. To test admin functions locally, set these **before the first run**:

```bat
set ADMIN_EMAIL=you@example.com
set ADMIN_PASSWORD=use-a-unique-password-at-least-16-characters
py app.py
```

If you already ran the app before setting the admin variables, remove the local `cardplug.db` only if you do not need its data, then restart. Never delete a production database to reset an administrator.

## Deploy to Render

1. Create a GitHub account at https://github.com/ and a Render account at https://render.com/.
2. Create a private GitHub repository and upload the files in this folder. Do not upload real secrets or `.env` files.
3. In Render, choose **New → Blueprint**, connect the repository, and let Render read `render.yaml`.
4. When prompted, enter `ADMIN_EMAIL` and a unique `ADMIN_PASSWORD` (at least 16 characters). Keep these secret.
5. Review the PostgreSQL database plan and expected cost before confirming. Render plan availability and pricing can change.
6. Deploy. Render will provide a `*.onrender.com` address. Open it and test `/health`, registration, login, trade submission, and admin updates.
7. Once deployed over HTTPS, ensure `COOKIE_SECURE=true` remains set. Set a strong `SECRET_KEY` in Render environment variables if you replace the generated value.

If the Blueprint setup cannot provision a database with the selected plan, create a Render PostgreSQL database separately and set the web service's `DATABASE_URL` to its **Internal Database URL**. Do not publish that URL.

## Environment variables

- `SECRET_KEY`: long random secret used for session and CSRF security.
- `DATABASE_URL`: PostgreSQL URL in production; SQLite default for local development.
- `ADMIN_EMAIL`: initial administrator email; only creates the admin if no account with that email exists.
- `ADMIN_PASSWORD`: initial administrator password; used only when creating that account.
- `COOKIE_SECURE`: set to `true` on HTTPS production deployment.
- `PORT`: hosting platform's web port; defaults to 5000 locally.

## Included functionality

- Customer accounts with password hashing and CSRF protection.
- Customer dashboard and trade-request history.
- Admin-only rate management and trade-status management.
- Indicative NGN estimate calculated from the rate snapshot at submission time.
- PostgreSQL-ready configuration and Render Blueprint.
- Security headers, secure cookie options, and basic form validation.

## Not included yet

- Email verification, password reset, 2FA, account lockout/rate limiting.
- Gift-card image upload or external card balance verification.
- Automated bank payout integration, payment webhooks, reconciliation, or provider credentials.
- KYC/AML, fraud scoring, audit-log exports, dispute process, or notifications.

Do not use this starter as-is to hold customer balances or process irreversible payouts.
