// Small progressive enhancement only. Server-side validation remains authoritative.
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('form').forEach((form) => {
    form.addEventListener('submit', () => {
      const button = form.querySelector('button[type="submit"]');
      if (button && form.checkValidity()) {
        button.dataset.originalText = button.textContent;
        button.disabled = true;
        button.textContent = 'Please wait…';
        // Re-enable if the browser blocks navigation for any reason.
        window.setTimeout(() => { button.disabled = false; button.textContent = button.dataset.originalText || 'Submit'; }, 8000);
      }
    });
  });
});
